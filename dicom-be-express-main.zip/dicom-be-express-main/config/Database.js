import { Sequelize } from "sequelize";

const db = new Sequelize("db_dicom", "root", "", {
  host: "localhost",
  dialect: "mysql",
});

export default db;
